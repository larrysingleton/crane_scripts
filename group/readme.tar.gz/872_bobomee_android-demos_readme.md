Android Develop Demos

-----

整理开发和学习的samples...


- AndroidAnimations : Android 动画学习Demo

- AndroidOrm ： Android 数据库学习Demo

- Android_WebView_Reference ：WebView 视频全屏播放解决方案

- AnnotationDemo ： Android 注解学习Demo

- Dagger2Sample : Android 依赖注入 Dagger2学习Demo

- MVP ：简单的 MVP 示例（使用github api）

- Mortar_Flow_Samples : Square的 Mortar 与 Flow 库学习 Demo

- ProviderTutorial ： ContentProvider学习之旅

- blogcodes ：Android 博客code

- common ： Android常用工具合集和bug收集

- retrofit2 : 网络库 Retrofit2 使用与封装

