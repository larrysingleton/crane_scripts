# hbworkspace2-100

(1)  Name :- ActionBarSearchView
Description :- Action bar search view.

(2)  Name :- Adsfree
Description :- Admob integration.

(3)  Name :- AndroidDayDreamDemo
Description :- Day dream demo.

(4)  Name :- android query demo live
Description :- Google play live app details parsing.

(5)  Name :- Arc GIS map
Description :- Arc gis map integration without hash key.

(6)  Name :- aviarySdk
Description :- Aviary integration for image operations.

(7)  Name :- BetterGestureDetector
Description :- Gesture accrate detection.

(8)  Name :- BlinkText
Description :- Blinking text.

(9)  Name :- BuzzBoxSDKHelloWorld
Description :- Buzz box integration cron scheduler.

(10)  Name :- CircularProgressBar
Description :- Circular progress bar.

(11)  Name :- ContactNumbersDemo
Description :- Get contact details from device.

(12)  Name :- ControlViewheight
Description :- Manage height of specific view.

(13)  Name :- ControlViewHeightSeekbar
Description :- Two listview manage appropriate hieght.

(14)  Name :- DownloadManagerAndroid
Description :- Download specific file online.

(15)  Name :- Facebook Integration
Description :- Facebook integration.

(16)  Name :- Graphview
Description :- Graphview demo.

(17)  Name :- HB 1337
Description :- Virus and antivirus.

(18)  Name :- HomeButtonEvent
Description :- Block home button press.

(19)  Name :- HomeLauncher
Description :- Home launcher demo.

(20)  Name :- InAppPurchaseTut
Description :- InAppPurchase demo.

(21)  Name :- KeyboardCustom
Description :- Creating Custom keyboard demo.

(22)  Name :- MapDemoGeofencing
Description :- Location map for geo fencing.

(23)  Name :- MapDemoV2Final
Description :- Map demo for google version 2.

(24)  Name :- OpenGLESSquare
Description :- Opengl moving square.

(25)  Name :- pagination numbering 2
Description :- Pagination type 2.

(26)  Name :- Pagination numbering
Description :- Pagination type 1.

(27)  Name :- PhoneGapCordova
Description :- Phone gap simple cordova demo.

(28)  Name :- PhoneGapCordovaCamera
Description :- Phone gap for camera.

(29)  Name :- PhoneGapCordovaParsing
Description :- Phone gap for parsing.

(30)  Name :- PhoneGapCordovaSMS
Description :- Phone gap for sending sms.

(31)  Name :- RotatingWheel
Description :- Rotating wheel by user interaction.

(32)  Name :- RotatingWheelSocialsites
Description :- Rotating wheel by user interaction for socialsites.

(33)  Name :- RunningBackgroundServices
Description :- Get Running services in background for package name/class name.

(34)  Name :- SearchList
Description :- Searching from a specific list.

(35)  Name :- SearchViewContacts
Description :- Search from contacts details.

(36)  Name :- SlidingDrawer
Description :- Sliding drawer from bottom over another activity.

(37)  Name :- SpeechToTextDemo
Description :- Convert speech to text.

(38)  Name :- TextToSpeak
Description :- Convert text to speech.

(39)  Name :- TouchCordinates
Description :- Get coordinate of user touch intergration.

(40)  Name :- TreeViewListDemo
Description :- Tree view integration demo.

(41)  Name :- UninstallDeleteapp
Description :- Uninstall another app from my app after removing admin permission.

(42)  Name :- ViewPagerCustomWidthFragment
Description :- Fragment in viewpager.

(43)  Name :- WearableNotification
Description :- Wearable notification.

(44)  Name :- WearablePages
Description :- Wearable pages.

(45)  Name :- WidgetDemo
Description :- Widget demo.

(46)  Name :- CameraIntentAll
Description :- Camera demo for picture as well as video demo.

(47)  Name :- CameraOverlay
Description :- Camera overlay image as aim shooting game.

(48)  Name :- DrmIntegration
Description :- Drm Integration library for authorize users apk file.

(49)  Name :- SwipeRefreshLayout
Description :- SwipeRefreshLayout Pulltorefresh like google.

(50)  Name :- TwitterIntegration
Description :- Twitter Integration.

(51)  Name :- CameraADev
Description :- Custom Camera for picture as well as video capture from android developer.

(52)  Name :- DataBaseSQLiteCRUD
Description :- Simple SQLite CRUD funtions for contact database.

(53)  Name :- DataBaseSQLiteDBUtility
Description :- Simple SQLite DBUtility all files and basic operations.

(54)  Name :- CustomDropdownMenu
Description :- Custom Dropdown/Poup Menu.

(55)  Name :- CalenderSimpleView
Description :- Simple calender view as well as timestamp using calender class.

(56)  Name :- CalendarProviderADevIntent
Description :- Calender provider Intent from android developer.

(57)  Name :- AnimationTextViewAnimateLayoutChanges
Description :- Animation of adding  view  inside another view using animatelayoutchanges.

(58)  Name :- DragnDropLowVersion
Description :- Drag n drop funtionality for low version. 

(59)  Name :- GoogleWalletAdev
Description :- Google Wallet Integration  from android developer.

(60)  Name :- AndroidShootingGame
Description :- Android Shooting Game without opengl.

(61)  Name :- ViewPagerAnimation
Description :- ViewPager page transformation for pages like alpha,scaling,rotation.

(62)  Name :- GoogleCloudWirelessPrintingIntent
Description :- Google cloud wireless printing integration from google developer. 

(63)  Name :- Barcode_or_QRCode_Scanner_openurl
Description :- Barcord/QR code scanner from google play and open result url in browser.

(64)  Name :- MSServerListSyncSample
Description :- List Sync Sample using MS Server.

(65)  Name :- SlidingMenuAPI
Description :- Sliding Menu jeremyfeinstein  library like facebook,gmail,etc.

(66)  Name :- GCMIntegration
Description :- Google cloud messageing integration for notification.

(67)  Name :- NoiseAlert
Description :- Detect noise or blow sound.

(68)  Name :- GregorianCalendar
Description :- Basic Gregorian Calendar information.

(69)  Name :- getVariableName
Description :- Get name of the variable not its value.

(70)  Name :- GoogleAnalyticsV4Adev
Description :- Google analytics integration V4.

(71)  Name :- FlipboardAnimationAdev
Description :- Animation like Flipboard.

(72)  Name :- Html5Camera
Description :- Camera in Html5 without phonegap.

(73)  Name :- CopyPasteClipboard
Description :- Copy & Paste Clipboard textual data.

(74)  Name :- AndroidPhpMysql
Description :- Php and Mysql data parsing in android.

(75)  Name :- SpellChecker
Description :- Check spelling and give appropriate suggestion for enter text.

(76)  Name :- PdfReader
Description :- Read pdf file.Barcode/QR code scanner.

(77)  Name :- BarcodeQRcodeIntegration  
Description :- Barcode/QR code scanner using ZbarScanner lib and also Zxing lib without intent.

(78)  Name :- InstagramIntegrationApi
Description :- Instagram Integration using sample demo.

(79)  Name :- Logger
Description :- Read logger/logcat using api.

(80)  Name :- SmsControl
Description :- Control device via sms codes.

(81)  Name :- EncryptDecryptString
Description :- Encrypt string and Decrypt the same string.

(82)  Name :- FloatingActionButton
Description :- Floating Action Button.

(83)  Name :- DownloadAndUnzipFile
Description :- Download And Unzip File.

(84)  Name :- MoPubAd
Description :- MoPub Ad Banner integration .

(85)  Name :- ListViewParsingDB_AndroidStudio
Description :- ListView Parsing in android studio.

(86)  Name :- CustomCamera_AS
Description :- Custom Camera using surfaceview.

(87)  Name :- ResizeableBox_AS
Description :- Resizeable Box like crop.

(88)  Name :- AudioRecorder_AS
Description :- Audio Recorder.

(89)  Name :- DateAndTimePicker_AS
Description :- Date And Time Picker.

(90)  Name :- CustomActionBar_AS
Description :- Simple Custom ActionBar. 

(91)  Name :- CustomSpinner_AS
Description :- Custom Spinner with default text item.

(92)  Name :- SendEmail_AS
Description :- Send email in background after authentication.

(93)  Name :- GoogleAnalytics_AS
Description :- GoogleAnalytics integration demo for crash and screen.

(94)  Name :- BroadcastReciever_AS
Description :- Broadcast Reciever for sms ,call and boot receiver.

(95)  Name :- Azure
Description :- Azure storage gsi credentials zip dowload.

(96)  Name :- InAppPurchase_AS
Description :- In App Purchase simple demo.

(97)  Name :- iOS_Listview
Description :- Simple Listview in ios.

(98)  Name :- iOS_Database
Description :- Sqlite Database in ios.

(99)  Name :- MessangerList_AS
Description :- Messanger Listview UI send and recieve.

(100)  Name :- FindingFriend_AS
Geofencing for enter and exit another pin.
