# AndroidTools
this is android tools for view  autoscroll view and coupon view ；for  RXJava Retrofit MVP etc;
Pay attention to progress 

* 轻松搞定 Android M 动态权限检测；

* 上下自动滚动，实例如京东、淘宝、一号店等 Android app里的上下滚动动态；

* 自定义的优惠券view、淘宝支付动效；

* RXJava Retrofit MVP实战；

* 添加购物车动效；

* 使用三阶贝塞尔曲线模拟运动路径。一个模拟贝塞尔曲线的网站，可以在线模拟出想要的曲线 http://myst729.github.io/bezier-curve/

* 开发过程中常用的工具类 AppUtil  DensityUtil EncodeUtil ScreenUtil StringUtil EncryptUtil

* 无限重复、自动滚动的ImageView；



#  效果图

![image](https://github.com/GJson/AndroidTools/blob/master/gif/main.gif)    

* 上下自动滚动，实例如京东、淘宝、一号店等 Android app里的上下滚动动态；

![image](https://github.com/GJson/AndroidTools/blob/master/gif/three.gif)    





* 添加购物车动效;

![image](https://github.com/GJson/AndroidTools/blob/master/gif/four.gif) 





* 自定义的优惠券view，以及支付宝支付动效；

![image](https://github.com/GJson/AndroidTools/blob/master/gif/one.gif)    
 




* RXJava Retrofit MVP实战

![image](https://github.com/GJson/AndroidTools/blob/master/gif/two.gif)   





* 三阶贝塞尔曲线动效

![image](https://github.com/GJson/AndroidTools/blob/master/gif/five.gif)   




   
