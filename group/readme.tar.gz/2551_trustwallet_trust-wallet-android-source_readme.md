# Trust - Ethereum Wallet for Android

[![Build Status](https://travis-ci.org/TrustWallet/trust-wallet-android.svg?branch=master)](https://travis-ci.org/TrustWallet/trust-wallet-android)
[![License](https://img.shields.io/badge/license-GPL3-green.svg?style=flat)](https://github.com/fastlane/fastlane/blob/master/LICENSE)

[<img src="https://raw.githubusercontent.com/TrustWallet/trust-wallet-android-source/master/resources/android_cover.png">](https://play.google.com/store/apps/details?id=com.wallet.crypto.trustapp)

[<img src=https://play.google.com/intl/en_us/badges/images/generic/en_badge_web_generic.png height="88">](https://play.google.com/store/apps/details?id=com.wallet.crypto.trustapp)

Welcome to Trust's open source Android app!

Please read our post on why Android open source development harm our users: https://medium.com/@trustwallet/why-open-sourcing-android-app-could-be-a-harm-to-the-crypto-community-fb3ae1707dc6

Website: https://trustwalletapp.com

Download Android version: https://play.google.com/store/apps/details?id=com.wallet.crypto.trustapp

Blog: https://medium.com/@trustwallet


