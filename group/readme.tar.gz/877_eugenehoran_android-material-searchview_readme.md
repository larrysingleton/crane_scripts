# Android-Material-SearchView

**Update**
- It has been a while since I worked on this project. I figured I would come back to it and convert it to a library. 

*TODO*
- everything


In the process of converting to a library. It is a mess at the moment but will be updating it over time. 

<img src="https://media.giphy.com/media/26Ff0H71r4BS3kEq4/giphy.gif" width="220" />


<p float="top">
<img src="https://github.com/EugeneHoran/Android-Material-SearchView/blob/master/images/device-2017-12-29-144222.png" width="220" />
<img src="https://github.com/EugeneHoran/Android-Material-SearchView/blob/master/images/device-2017-12-29-144241.png" width="220" />
</p>
