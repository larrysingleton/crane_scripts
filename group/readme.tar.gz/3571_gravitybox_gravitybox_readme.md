GravityBox
==========

XPosed Tweak Box for devices running Android 8.x (Oreo)

Visit the [official support thread](https://forum.xda-developers.com/xposed/modules/app-gravitybox-v8-0-0-beta-1-tweak-box-t3739929) at XDA for more info.

Copyright (C) 2018 Peter Gregus (xgravitybox@gmail.com)
