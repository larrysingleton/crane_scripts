SeriesGuide Show Manager
========================

This GitHub repository hosts the code for the Android app SeriesGuide.

For more information about SeriesGuide have a look at [seriesgui.de](https://seriesgui.de).

Contributing
------------

See [CONTRIBUTING.md](CONTRIBUTING.md).

License
-------

Created by [Uwe Trottmann](https://uwetrottmann.com).

See full [list of contributors](https://github.com/UweTrottmann/SeriesGuide/graphs/contributors).

Except where noted otherwise, released into the [public domain](UNLICENSE).
Do not just copy, make it better.
