[![Build Status](https://travis-ci.org/tasks/tasks.svg?branch=master)](https://travis-ci.org/tasks/tasks) [![codecov](https://codecov.io/gh/tasks/tasks/branch/master/graph/badge.svg)](https://codecov.io/gh/tasks/tasks)

[![Donate with Bitcoin](https://img.shields.io/badge/bitcoin-donate-yellow.svg)](https://en.cryptobadges.io/donate/136mW34jW3cmZKhxuTDn3tHXMRwbbaRU8s)
[![PayPal donate button](https://img.shields.io/badge/paypal-donate-yellow.svg)](https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=alex@tasks.org)

<a href='https://play.google.com/store/apps/details?id=org.tasks&utm_source=global_co&utm_medium=prtnr&utm_content=Mar2515&utm_campaign=PartBadge&pcampaignid=MKT-Other-global-all-co-prtnr-py-PartBadge-Mar2515-1'><img alt='Get it on Google Play' src='https://play.google.com/intl/en_us/badges/images/generic/en_badge_web_generic.png' width="210" height="80"/></a>
<a href='https://f-droid.org/repository/browse/?fdid=org.tasks'><img src='https://f-droid.org/wiki/images/f/ff/F-Droid-button_available-on_bigger.png' /></a>
[![Get it on Amazon App Store](https://images-na.ssl-images-amazon.com/images/G/01/mobile-apps/devportal2/res/images/amazon-underground-app-us-black.png)](https://www.amazon.com/gp/product/B00QHGTL7O/ref=mas_pm_tasks_astrid_to_do_list_clone)

Visit the wiki to
* [help with translations](http://tasks.org/docs/translations.html)
* [become a beta tester](http://tasks.org/docs/pre_release_testing.html)
* [get started with development](http://tasks.org/docs/develop.html)
